CREATE TABLE usuarios (id SERIAL, email varchar(50), nombre varchar(50),
password varchar(50), auth BOOLEAN);